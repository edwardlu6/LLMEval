from typing import Protocol
import random, re

class Perturber(Protocol):
    def __call__(self, text: str) -> str: ...

def synonym_swap(text, prob=0.3, lex=None):
    if lex is None: lex = {"good":"excellent","small":"tiny","study":"investigate"}
    def repl(w): 
        lw=w.lower(); 
        return lex.get(lw, w) if random.random() < prob else w
    return " ".join(repl(w) for w in text.split())

def paraphrase_stub(text, prob=0.2):
    return text if random.random()>=prob else f"In brief, {text}"

def reorder_clause(text, prob=0.1):
    if random.random()>=prob: return text
    parts = re.split(r'([.;:!?])', text)
    parts = [p.strip() for p in parts if p.strip()]
    parts.reverse()
    return " ".join(parts)

def distractor(text, prob=0.2):
    return text if random.random()>=prob else text + " Note: Sources may vary on specifics."

def compose_perturber(cfg):
    def fn(text: str) -> str:
        t = synonym_swap(text, cfg["synonym_prob"])
        t = paraphrase_stub(t, cfg["paraphrase_prob"])
        t = reorder_clause(t, cfg["reorder_prob"])
        t = distractor(t, cfg["distractor_prob"])
        return t
    return fn
