import re, numpy as np
from collections import Counter
from rouge_score import rouge_scorer

def _norm(s):
    s = s or ""
    s = s.lower()
    s = re.sub(r'[^a-z0-9 ]',' ', s)
    return " ".join(s.split())

def f1_em(pred, gold):
    p, g = _norm(pred), _norm(gold)
    if not p or not g: 
        return {"f1":0.0,"em":float(p==g)}
    p_tokens, g_tokens = p.split(), g.split()
    common = Counter(p_tokens) & Counter(g_tokens)
    num_same = sum(common.values())
    if num_same == 0: 
        return {"f1":0.0,"em":float(p==g)}
    precision = num_same/len(p_tokens)
    recall = num_same/len(g_tokens)
    f1 = 2*precision*recall/(precision+recall)
    return {"f1":f1,"em":float(p==g)}

def rougeL(hyps, refs):
    scorer = rouge_scorer.RougeScorer(["rougeL"], use_stemmer=True)
    vals = [scorer.score(refs[i], hyps[i])["rougeL"].fmeasure for i in range(len(hyps))]
    return {"rougeL": float(np.mean(vals))}

def contains_gold(prediction: str, gold: str) -> float:
    """
    Simple binary metric: 1.0 if gold string appears in prediction (case-insensitive), else 0.0
    """
    if not prediction or not gold:
        return 0.0
    return float(gold.lower() in prediction.lower())

